﻿global using Prototype;
global using System;
