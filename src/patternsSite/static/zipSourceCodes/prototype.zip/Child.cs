﻿namespace Prototype;
class Child
{
    public int Age { get; set; }
}

