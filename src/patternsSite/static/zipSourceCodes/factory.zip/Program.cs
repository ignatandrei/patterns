﻿using Factory;

FactoryDemo.FactoryDBConnection();