﻿using Strategy;

StrategyDemo.SortWithDifferentStrategies();