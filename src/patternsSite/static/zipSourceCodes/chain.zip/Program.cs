using Chain;

try
{
    ChainDemo.SecondException();
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}


