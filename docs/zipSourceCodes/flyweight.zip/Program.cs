﻿using Flyweight;

FlyweightDemo.Demo();