﻿using Decorator;

DecoratorDemo.Stream_Crypto_Gzip();