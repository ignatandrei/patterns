﻿using AbstractFactory;

AbstractFactoryDemo.Demo();
