﻿DirectoryEnumerableDemo.DirectoryEnumerableFiles(3);
