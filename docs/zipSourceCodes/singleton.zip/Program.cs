﻿using Singleton;

SingletonDemo.GetFactory();
