﻿using Visitor;

VisitorDemo.VisitMethods();