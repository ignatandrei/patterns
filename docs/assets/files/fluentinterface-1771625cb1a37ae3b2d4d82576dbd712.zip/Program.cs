﻿using FluentInterface;
using Microsoft.Extensions.DependencyInjection;

ServiceCollection services = new ();

services
    .AddServices()
    .AddServices();