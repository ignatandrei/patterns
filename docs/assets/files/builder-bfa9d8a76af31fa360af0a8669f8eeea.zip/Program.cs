﻿using System;
using System.Data.SqlClient;

namespace Builder
{
    class Program
    {
        static void Main(string[] args)
        {
            UriBuilderDemo.UriMod();
            ConnectionStringDemo.ConnectionString();
        }

        

        
    }
}
