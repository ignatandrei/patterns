﻿using Observer;

ObserverDemo.Demo();